from fastapi import FastAPI, Query, HTTPException
import uvicorn

app = FastAPI()

@app.post("/send-signal/")
async def receive_signal(signal: str = Query(None, description="Signal value: '0', '1', or None")):
    if signal == '0':
        print("Received signal: No audio playing")
        return {"message": "Signal received no playing", "status": 0}
    elif signal == '1':
        print("Received signal: Audio is playing")
        return {"message": "Signal received audio playing", "status": 1}
    elif signal is None or signal == '':
        print("Received signal: Signal is null or empty")
        return {"message": "Signal received empty", "status": 2}
    else:
        raise HTTPException(status_code=400, detail="Invalid signal value")

from fastapi import FastAPI, Query, HTTPException
import uvicorn

app = FastAPI()

# Store the latest signal value
signal_store = {"signal": None}

@app.post("/send-signal/")
async def receive_signal(signal: str = Query(None, description="Signal value: '0', '1', or None")):
    if signal == '0':
        print("Received signal: No audio playing")
        signal_store["signal"] = 0
        return {"message": "Signal received no playing", "status": 0}
    elif signal == '1':
        print("Received signal: Audio is playing")
        signal_store["signal"] = 1
        return {"message": "Signal received audio playing", "status": 1}
    elif signal is None or signal == '':
        print("Received signal: Signal is null or empty")
        signal_store["signal"] = 2
        return {"message": "Signal received empty", "status": 2}
    else:
        raise HTTPException(status_code=400, detail="Invalid signal value")
    
@app.get("/get-signal/")
async def get_signal():
    current_signal = signal_store.get("signal", None)
    return {"current_signal": current_signal}




if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=3000)