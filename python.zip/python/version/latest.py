import psutil
import time
import socket

def is_any_audio_file_playing():
    audio_extensions = ['.mp3','.mp4','.mov','.avi', '.wav', '.flac', '.aac', '.ogg', '.m4a']
    for proc in psutil.process_iter(['pid', 'name', 'open_files']):
        try:
            open_files = proc.info.get('open_files')
            if open_files:
                for file in open_files:
                    if any(file.path.endswith(ext) for ext in audio_extensions):
                        return True
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass
    return False

def send_signal_to_server(signal, server_ip, server_port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.connect((server_ip, server_port))
            s.sendall(signal.encode())
        except ConnectionRefusedError:
            print("Connection to server refused. Check if the server is running.")
        except Exception as e:
            print(f"An error occurred: {e}")

def monitor_audio_files(server_ip, server_port):
    send_signal_to_server('0', server_ip, server_port)
    print("Sent initial signal '0'.")

    last_status = None

    while True:
        current_status = is_any_audio_file_playing()
        if current_status != last_status:
            if current_status:
                print("Audio or video file is playing.")
                send_signal_to_server('1', server_ip, server_port)
            else:
                print("No audio or video file is playing.")
                send_signal_to_server('0', server_ip, server_port)
            
            last_status = current_status
        
        time.sleep(1)

if __name__ == "__main__":
    server_ip = '127.0.0.1'
    server_port = 3000
    monitor_audio_files(server_ip, server_port)