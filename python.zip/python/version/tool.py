import psutil 
import time
import socket

def is_file_playing(file_name):
    for proc in psutil.process_iter(['pid', 'name', 'open_files']):
        try:
            open_files = proc.info.get('open_files')
            if open_files:
                for file in open_files:
                    if file_name in file.path:
                        return True
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass
    return False

def send_signal_to_server(signal, server_ip, server_port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((server_ip, server_port))
        s.sendall(signal.encode())

def monitor_file(file_name, server_ip, server_port):
    last_status = None
    while True:
        current_status = is_file_playing(file_name)
        if current_status != last_status:
            if current_status:
                print(f"{file_name} running.")
                send_signal_to_server('1', server_ip, server_port)
            else:
                print(f"{file_name} not run.")
                send_signal_to_server('0', server_ip, server_port)
            last_status = current_status
        time.sleep(5)  # Adjust the delay as needed (e.g., 5 seconds)

if __name__ == "__main__":
    server_ip = '127.0.0.1'  # Địa chỉ localhost
    server_port = 65432
    monitor_file("video", server_ip, server_port)
