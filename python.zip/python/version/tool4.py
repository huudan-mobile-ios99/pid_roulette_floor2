import psutil
import time
import socket

# Hàm kiểm tra xem có bất kỳ file âm thanh nào đang phát hay không
def is_any_audio_file_playing():
    audio_extensions = ['.mp3','.mp4','.mov','.avi', '.wav', '.flac', '.aac', '.ogg', '.m4a']  # Các đuôi tệp âm thanh phổ biến
    for proc in psutil.process_iter(['pid', 'name', 'open_files']):
        try:
            open_files = proc.info.get('open_files')
            if open_files:
                for file in open_files:
                    if any(file.path.endswith(ext) for ext in audio_extensions):
                        return True
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass
    return False

# Hàm gửi tín hiệu đến server
def send_signal_to_server(signal, server_ip, server_port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.connect((server_ip, server_port))
            s.sendall(signal.encode())
        except ConnectionRefusedError:
            print("Kết nối tới server bị từ chối. Kiểm tra server đã chạy chưa.")

# Hàm giám sát và gửi tín hiệu khi có file âm thanh đang phát
def monitor_audio_files(server_ip, server_port):
    last_status = None  # Trạng thái trước đó của âm thanh

    while True:
        current_status = is_any_audio_file_playing()
        
        # Chỉ gửi tín hiệu khi trạng thái thay đổi
        if current_status != last_status:
            if current_status:
                print("Có file âm thanh đang phát.")
                send_signal_to_server('1', server_ip, server_port)
            else:
                print("Không có file âm thanh nào đang phát.")
                send_signal_to_server('0', server_ip, server_port)
            
            last_status = current_status  # Cập nhật trạng thái trước đó
        
        time.sleep(1)  # Kiểm tra trạng thái mỗi 0.5 giây

if __name__ == "__main__":
    server_ip = '127.0.0.1'  # Địa chỉ localhost
    server_port = 3000
    monitor_audio_files(server_ip, server_port)
