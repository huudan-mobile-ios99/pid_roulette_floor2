import psutil
import time
import requests

# Function to check if any audio file is currently playing
def is_any_audio_file_playing():
    audio_extensions = ['.mp3', '.mp4', '.mov', '.avi', '.wav', '.flac', '.aac', '.ogg', '.m4a']  # Common audio file extensions
    for proc in psutil.process_iter(['pid', 'name', 'open_files']):
        try:
            open_files = proc.info.get('open_files')
            if open_files:
                for file in open_files:
                    if any(file.path.endswith(ext) for ext in audio_extensions):
                        return True
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass
    return False

# Function to send signal to the FastAPI server
def send_signal_to_server(signal, server_url):
    try:
        response = requests.post(server_url, json={"signal": signal})
        response.raise_for_status()
    except requests.RequestException as e:
        print(f"Error sending signal to server: {e}")

# Function to monitor audio files and send signal when audio is playing
def monitor_audio_files(server_url):
    last_status = None  # Previous audio status

    while True:
        current_status = is_any_audio_file_playing()
        
        # Send signal only if the status changes
        if current_status != last_status:
            if current_status:
                send_signal_to_server('1', server_url)  # Audio is playing
            else:
                send_signal_to_server('0', server_url)  # No audio playing
            
            last_status = current_status  # Update previous status
        
        time.sleep(1)  # Check status every 1 second

if __name__ == "__main__":
    server_url = 'http://127.0.0.1:3333/send-signal/'
    monitor_audio_files(server_url)