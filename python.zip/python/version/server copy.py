from fastapi import FastAPI, Query, HTTPException
import uvicorn

app = FastAPI()

@app.post("/send-signal/")
async def receive_signal(signal: str = Query(None, description="Signal value: '0', '1', or None")):
    if signal == '0':
        print("Received signal: No audio playing")
        return {"message": "Signal received", "status": 0}
    elif signal == '1':
        print("Received signal: Audio is playing")
        return {"message": "Signal received", "status": 1}
    elif signal is None or signal == '':
        print("Received signal: Signal is null or empty")
        return {"message": "Signal received", "status": 2}
    else:
        raise HTTPException(status_code=400, detail="Invalid signal value")

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=3000)