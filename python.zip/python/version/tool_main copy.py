import psutil
import time
import requests

# Function to check if any audio file is currently playing
def is_any_audio_file_playing():
    audio_extensions = ['.mp3', '.mp4', '.mov', '.avi', '.wav', '.flac', '.aac', '.ogg', '.m4a']
    detected_files = []
    for proc in psutil.process_iter(['pid', 'name', 'open_files']):
        try:
            open_files = proc.info.get('open_files')
            if open_files:
                for file in open_files:
                    if any(file.path.endswith(ext) for ext in audio_extensions):
                        detected_files.append(file.path)
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass

    return bool(detected_files)

# Function to send signal to the FastAPI server
def send_signal_to_server(signal, server_url):
    try:
        response = requests.post(server_url, json={"signal": signal})
        response.raise_for_status()
        print(f"Sent signal '{signal}' to server.")
    except requests.RequestException as e:
        print(f"Error sending signal to server: {e}")

# Function to monitor audio files and send signal based on playback status
def monitor_audio_files(server_url):
    last_status = None  # Previous audio status

    while True:
        current_status = is_any_audio_file_playing()

        if current_status:
            if last_status is None or not last_status:
                # Audio started playing or resumed
                send_signal_to_server('1', server_url)
        else:
            if last_status:
                # Audio stopped playing
                send_signal_to_server('0', server_url)

        last_status = current_status  # Update previous status

        time.sleep(1)  # Check status every 1 second

if __name__ == "__main__":
    server_url = 'http://127.0.0.1:3000/send-signal/'
    monitor_audio_files(server_url)